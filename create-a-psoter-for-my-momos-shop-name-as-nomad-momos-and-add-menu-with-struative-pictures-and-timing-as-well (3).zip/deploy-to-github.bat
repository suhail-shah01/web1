@echo off
REM 🚀 Bungus Valley - GitHub Pages Deployment Script (Windows)
REM This script automates the deployment process to GitHub Pages

echo.
echo ============================================
echo   Bungus Valley Website - GitHub Deployment
echo ============================================
echo.

REM Check if git is installed
where git >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Git is not installed. Please install Git first.
    echo Visit: https://git-scm.com/download/win
    pause
    exit /b 1
)
echo [OK] Git is installed
echo.

REM Check if this is a git repository
if not exist .git (
    echo Initializing Git repository...
    git init
    echo [OK] Git repository initialized
    echo.
)

REM Get GitHub username
set /p GITHUB_USERNAME="Enter your GitHub username: "
echo.

REM Get repository name
set /p REPO_NAME="Enter repository name (e.g., bungus-valley): "
echo.

REM Set up repository remote
echo Setting up repository remote...
git remote add origin https://github.com/%GITHUB_USERNAME%/%REPO_NAME%.git 2>nul
if %ERRORLEVEL% EQU 0 (
    echo [OK] Remote configured
) else (
    echo [INFO] Remote already exists or was updated
)
echo.

REM Build the project
echo Building project...
call npm run build
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Build failed! Please fix errors and try again.
    pause
    exit /b 1
)
echo [OK] Build successful
echo.

REM Add all files to git
echo Adding files to git...
git add .
echo [OK] Files added
echo.

REM Create commit
echo Creating commit...
git commit -m "Deploy Bungus Valley website to GitHub Pages" 2>nul
if %ERRORLEVEL% NEQ 0 (
    git commit -m "Initial commit"
)
echo [OK] Commit created
echo.

REM Set main branch
echo Setting main branch...
git branch -M main
echo [OK] Main branch set
echo.

REM Push to GitHub
echo Pushing to GitHub...
git push -u origin main
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [WARNING] Push failed. You may need to authenticate with GitHub.
    echo Follow the instructions or use a Personal Access Token.
    echo.
)
echo.

REM Deploy to gh-pages
echo Deploying to GitHub Pages...
call npm run deploy
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Deployment failed! Please check errors above.
    pause
    exit /b 1
)
echo [OK] Deployment successful!
echo.

REM Show final information
echo ============================================
echo   DEPLOYMENT COMPLETE!
echo ============================================
echo.
echo Your website will be live at:
echo   https://%GITHUB_USERNAME%.github.io/%REPO_NAME%/
echo.
echo Please wait 2-5 minutes for GitHub to build and deploy.
echo.
echo Next Steps:
echo   1. Go to: https://github.com/%GITHUB_USERNAME%/%REPO_NAME%
echo   2. Click Settings ^> Pages
echo   3. Ensure Source is set to 'gh-pages' branch
echo   4. Wait for deployment to complete
echo   5. Visit your live website!
echo.
echo For custom domain ^(bungusvalley.com^):
echo   - Add DNS records at your domain registrar
echo   - Configure in Settings ^> Pages ^> Custom domain
echo   - See GITHUB_PAGES_DEPLOYMENT.md for details
echo.
echo To update in the future:
echo   git add .
echo   git commit -m "Your update message"
echo   git push
echo   npm run deploy
echo.
echo ============================================
echo   Good luck with Bungus Valley Tourism!
echo ============================================
echo.
pause
