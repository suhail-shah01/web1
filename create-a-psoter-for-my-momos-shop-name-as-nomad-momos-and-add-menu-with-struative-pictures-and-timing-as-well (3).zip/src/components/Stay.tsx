import { Tent, Home, Wifi, Coffee, Flame, Star, Phone } from 'lucide-react';

export default function Stay() {
  const accommodationTypes = [
    {
      icon: <Tent className="h-8 w-8" />,
      type: 'Camping Sites',
      description: 'Designated camping areas with basic facilities',
      price: '₹500-1,500/night',
      features: ['Tent rental available', 'Common washrooms', 'Bonfire area', 'Mountain views'],
      bestFor: 'Adventure seekers, Groups',
      availability: 'April to October',
    },
    {
      icon: <Home className="h-8 w-8" />,
      type: 'Homestays',
      description: 'Experience local Kashmiri hospitality in nearby villages',
      price: '₹1,000-2,500/night',
      features: ['Home-cooked meals', 'Local experience', 'Warm rooms', 'Cultural immersion'],
      bestFor: 'Families, Cultural experiences',
      availability: 'Year-round (weather permitting)',
    },
    {
      icon: <Home className="h-8 w-8" />,
      type: 'Guest Houses',
      description: 'Basic guest houses in Kupwara and Handwara towns',
      price: '₹1,500-3,500/night',
      features: ['Private rooms', 'Attached bathrooms', 'Hot water', 'Parking'],
      bestFor: 'Comfort seekers, Longer stays',
      availability: 'Year-round',
    },
  ];

  const campingTips = [
    'Book camping spots in advance during peak season (May-June)',
    'Carry warm clothing even in summer (temperatures drop at night)',
    'Bring your own sleeping bag for hygiene and comfort',
    'Respect the environment - carry back all waste',
    'Keep food secured to avoid wildlife encounters',
    'Inform someone about your camping location and duration',
  ];

  const nearbyTowns = [
    {
      name: 'Kupwara',
      distance: '42 km from valley',
      options: 'Guest houses, Hotels, Homestays',
      facilities: 'Restaurants, ATMs, Medical facilities',
    },
    {
      name: 'Handwara',
      distance: '29 km from valley',
      options: 'Guest houses, Local stays',
      facilities: 'Basic restaurants, Shops',
    },
    {
      name: 'Srinagar',
      distance: '130 km from valley',
      options: 'Hotels, Houseboats, Resorts',
      facilities: 'All modern amenities, Airport',
    },
  ];

  return (
    <section id="stay" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-emerald-600 font-semibold text-sm uppercase tracking-wider">
            Rest & Relaxation
          </span>
          <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-900 mt-3 mb-6">
            Stay & Camping Options
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From rustic camping under the stars to comfortable homestays, 
            find the perfect accommodation for your Bungus Valley adventure
          </p>
        </div>

        {/* Accommodation Types */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {accommodationTypes.map((option, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 border border-gray-200 hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
            >
              <div className="w-16 h-16 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600 mb-4">
                {option.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{option.type}</h3>
              <p className="text-gray-600 mb-4">{option.description}</p>
              
              <div className="mb-4">
                <div className="text-2xl font-bold text-emerald-600">{option.price}</div>
                <div className="text-sm text-gray-500">per night</div>
              </div>

              <div className="space-y-2 mb-4">
                {option.features.map((feature, fIndex) => (
                  <div key={fIndex} className="flex items-center text-sm">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full mr-3 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-gray-200">
                <div className="text-sm">
                  <span className="text-gray-500">Best for: </span>
                  <span className="font-medium text-gray-900">{option.bestFor}</span>
                </div>
                <div className="text-sm">
                  <span className="text-gray-500">Available: </span>
                  <span className="font-medium text-gray-900">{option.availability}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Camping Tips */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-8 md:p-12 text-white mb-16">
          <h3 className="text-2xl md:text-3xl font-bold mb-6">Essential Camping Tips</h3>
          <div className="grid md:grid-cols-2 gap-6">
            {campingTips.map((tip, index) => (
              <div key={index} className="flex items-start">
                <div className="flex-shrink-0 w-8 h-8 bg-white/20 rounded-full flex items-center justify-center mr-4">
                  <span className="font-bold">{index + 1}</span>
                </div>
                <p className="text-emerald-50">{tip}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Nearby Towns */}
        <div className="mb-16">
          <h3 className="text-2xl md:text-3xl font-bold text-gray-900 text-center mb-8">
            Accommodation in Nearby Towns
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            {nearbyTowns.map((town, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-6 border border-gray-200">
                <h4 className="text-lg font-bold text-gray-900 mb-3">{town.name}</h4>
                <div className="space-y-3">
                  <div>
                    <div className="text-sm text-gray-500">Distance from Valley</div>
                    <div className="font-semibold text-gray-900">{town.distance}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Accommodation Options</div>
                    <div className="font-semibold text-gray-900">{town.options}</div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Facilities</div>
                    <div className="font-semibold text-gray-900">{town.facilities}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Booking Information */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-8">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Booking Information</h3>
            <p className="text-gray-700">
              Advance booking recommended during peak season (May-June)
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl p-6">
              <h4 className="font-bold text-gray-900 mb-4 flex items-center">
                <Phone className="h-5 w-5 mr-2 text-emerald-600" />
                Contact for Bookings
              </h4>
              <div className="space-y-3">
                <div>
                  <div className="text-sm text-gray-500">Tourism Office Kupwara</div>
                  <div className="font-semibold text-gray-900">+91 9876543210</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Local Guide Association</div>
                  <div className="font-semibold text-gray-900">+91 9876543211</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Email</div>
                  <div className="font-semibold text-gray-900">info@bungusvalley.com</div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6">
              <h4 className="font-bold text-gray-900 mb-4 flex items-center">
                <Star className="h-5 w-5 mr-2 text-emerald-600" />
                What to Expect
              </h4>
              <ul className="space-y-2 text-gray-700">
                <li>• Basic amenities in camping areas</li>
                <li>• Limited electricity in remote areas</li>
                <li>• Mobile network may be intermittent</li>
                <li>• Carry cash (ATMs limited)</li>
                <li>• Respect local customs and environment</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Facilities Icon Legend */}
        <div className="mt-12 flex flex-wrap justify-center gap-6 text-sm text-gray-600">
          <div className="flex items-center">
            <div className="w-5 h-5 bg-emerald-600 rounded mr-2" />
            <span>Washroom Facilities</span>
          </div>
          <div className="flex items-center">
            <Flame className="h-5 w-5 mr-2" />
            <span>Bonfire Area</span>
          </div>
          <div className="flex items-center">
            <Coffee className="h-5 w-5 mr-2" />
            <span>Food Available</span>
          </div>
          <div className="flex items-center">
            <Wifi className="h-5 w-5 mr-2" />
            <span>Limited Connectivity</span>
          </div>
        </div>
      </div>
    </section>
  );
}
