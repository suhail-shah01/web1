import { Mountain, Trees, Droplets, Camera, Bird } from 'lucide-react';

export default function Attractions() {
  const attractions = [
    {
      icon: <Mountain className="h-8 w-8" />,
      title: 'Bod Bangus (Big Bungus)',
      description: 'The main valley spanning approximately 20x15 km, featuring vast alpine meadows perfect for trekking and camping. Surrounded by towering peaks, this elliptical bowl-shaped valley offers panoramic Himalayan views.',
      highlights: ['Linear elliptical bowl', 'East-west axis alignment', 'Vast open meadows', 'Mountain viewpoints'],
      color: 'from-emerald-500 to-teal-600',
    },
    {
      icon: <Trees className="h-8 w-8" />,
      title: 'Lokut Bangus (Small Bungus)',
      description: 'A smaller valley on the north-eastern side of the main valley, offering intimate experiences with nature. Perfect for those seeking solitude and peaceful moments amidst pristine surroundings.',
      highlights: ['Secluded location', 'Dense forests', 'Peaceful atmosphere', 'Wildlife spotting'],
      color: 'from-blue-500 to-indigo-600',
    },
    {
      icon: <Droplets className="h-8 w-8" />,
      title: 'Crystal Clear Streams',
      description: 'Multiple mountain streams and the Nallah Bungus river flow through the valleys, offering pristine water sources and excellent trout fishing opportunities. The sound of flowing water adds to the valley\'s serene ambiance.',
      highlights: ['Trout fishing', 'Natural water sources', 'Scenic spots', 'Photography locations'],
      color: 'from-cyan-500 to-blue-600',
    },
    {
      icon: <Trees className="h-8 w-8" />,
      title: 'Coniferous Forests (Budloo)',
      description: 'Dense coniferous forests surround the valleys, creating a unique ecological combination. These forests are home to diverse flora and provide habitat for various wildlife species.',
      highlights: ['Dense forest cover', 'Diverse flora', 'Wildlife habitat', 'Nature walks'],
      color: 'from-green-600 to-emerald-700',
    },
    {
      icon: <Camera className="h-8 w-8" />,
      title: 'Photography Points',
      description: 'Numerous vantage points throughout the valley offer spectacular photography opportunities. From sunrise over the peaks to wildflower meadows, every corner presents a perfect shot.',
      highlights: ['Sunrise viewpoints', 'Mountain panoramas', 'Wildlife photography', 'Landscape shots'],
      color: 'from-purple-500 to-pink-600',
    },
    {
      icon: <Bird className="h-8 w-8" />,
      title: 'Wildlife Corridors',
      description: 'Designated areas where wildlife is frequently spotted. Early morning and evening offer the best chances to see snow leopards, musk deer, brown bears, and various bird species.',
      highlights: ['Snow leopard territory', 'Bird watching', 'Musk deer habitat', 'Nature observation'],
      color: 'from-amber-500 to-orange-600',
    },
  ];

  return (
    <section id="attractions" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-emerald-600 font-semibold text-sm uppercase tracking-wider">
            Explore & Discover
          </span>
          <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-900 mt-3 mb-6">
            Tourism Attractions
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover the diverse landscapes and natural wonders that make 
            Bungus Valley a photographer's paradise and nature lover's dream
          </p>
        </div>

        {/* Attractions Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {attractions.map((attraction, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
            >
              {/* Icon Header */}
              <div className={`h-32 bg-gradient-to-br ${attraction.color} flex items-center justify-center text-white`}>
                <div className="transform group-hover:scale-110 transition-transform duration-300">
                  {attraction.icon}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {attraction.title}
                </h3>
                <p className="text-gray-600 mb-4 leading-relaxed">
                  {attraction.description}
                </p>

                {/* Highlights */}
                <div className="space-y-2">
                  {attraction.highlights.map((highlight, hIndex) => (
                    <div key={hIndex} className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{highlight}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Surrounding Mountains Info */}
        <div className="mt-16 bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 md:p-12 text-white">
          <h3 className="text-2xl md:text-3xl font-bold text-center mb-8">
            Surrounding Mountain Ranges
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center p-4 bg-white/10 rounded-xl">
              <div className="text-lg font-semibold mb-2">East</div>
              <div className="text-emerald-300">Rajwar & Mawar</div>
            </div>
            <div className="text-center p-4 bg-white/10 rounded-xl">
              <div className="text-lg font-semibold mb-2">West</div>
              <div className="text-emerald-300">Shamasbury & Dajlungun</div>
            </div>
            <div className="text-center p-4 bg-white/10 rounded-xl">
              <div className="text-lg font-semibold mb-2">North</div>
              <div className="text-emerald-300">Chowkibal & Karnah Guli</div>
            </div>
            <div className="text-center p-4 bg-white/10 rounded-xl">
              <div className="text-lg font-semibold mb-2">Range</div>
              <div className="text-emerald-300">Pir Panjal</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
