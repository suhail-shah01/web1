import { Tent, Mountain, Camera, Fish, Bird, Heart, Star, Zap } from 'lucide-react';

export default function Activities() {
  const activities = [
    {
      icon: <Tent className="h-10 w-10" />,
      title: 'Camping',
      description: 'Experience camping under the starlit Himalayan sky. Designated camping areas with basic facilities available. Perfect for groups and families seeking an authentic outdoor experience.',
      bestTime: 'April to September',
      difficulty: 'Easy to Moderate',
      duration: '1-3 nights',
      highlights: ['Starry night sky', 'Bonfire experiences', 'Mountain views', 'Fresh air'],
      color: 'from-orange-500 to-red-600',
    },
    {
      icon: <Mountain className="h-10 w-10" />,
      title: 'Trekking & Hiking',
      description: 'Explore numerous trails ranging from easy nature walks to challenging mountain treks. Routes offer breathtaking views of surrounding peaks and valleys.',
      bestTime: 'May to October',
      difficulty: 'Easy to Difficult',
      duration: '2-8 hours',
      highlights: ['Multiple trail options', 'Panoramic views', 'Wildlife spotting', 'Photography opportunities'],
      color: 'from-emerald-500 to-green-600',
    },
    {
      icon: <Camera className="h-10 w-10" />,
      title: 'Photography',
      description: 'Capture stunning landscapes, wildlife, and cultural moments. Every corner of the valley offers photogenic scenes from sunrise to sunset.',
      bestTime: 'Year-round (Best: April-June)',
      difficulty: 'Easy',
      duration: 'Flexible',
      highlights: ['Sunrise/Sunset points', 'Wildlife photography', 'Landscape shots', 'Cultural moments'],
      color: 'from-purple-500 to-pink-600',
    },
    {
      icon: <Fish className="h-10 w-10" />,
      title: 'Trout Fishing',
      description: 'The crystal-clear streams and Nallah Bungus river are home to trout. Fishing permits available locally. A peaceful and rewarding experience.',
      bestTime: 'May to September',
      difficulty: 'Easy to Moderate',
      duration: '2-6 hours',
      highlights: ['Trout species', 'Clear streams', 'Peaceful activity', 'Catch & release'],
      color: 'from-blue-500 to-cyan-600',
    },
    {
      icon: <Bird className="h-10 w-10" />,
      title: 'Bird Watching',
      description: 'Spot rare Himalayan bird species including pheasants, eagles, and migratory birds. Early morning offers the best viewing opportunities.',
      bestTime: 'April to August',
      difficulty: 'Easy',
      duration: '2-4 hours',
      highlights: ['Rare species', 'Migratory birds', 'Natural habitat', 'Binocular recommended'],
      color: 'from-amber-500 to-yellow-600',
    },
    {
      icon: <Heart className="h-10 w-10" />,
      title: 'Nature Walks',
      description: 'Leisurely walks through meadows and forests. Perfect for all ages and fitness levels. Experience the valley\'s flora and peaceful ambiance.',
      bestTime: 'April to October',
      difficulty: 'Easy',
      duration: '1-3 hours',
      highlights: ['Wildflower meadows', 'Forest trails', 'Fresh air', 'Relaxing pace'],
      color: 'from-teal-500 to-emerald-600',
    },
  ];

  const adventurePackages = [
    {
      name: 'Day Adventure',
      duration: '6-8 hours',
      activities: ['Nature walk', 'Photography', 'Picnic'],
      price: '₹1,500/person',
      includes: ['Guide', 'Permits', 'Basic refreshments'],
    },
    {
      name: 'Weekend Camping',
      duration: '2 days/1 night',
      activities: ['Camping', 'Trekking', 'Bonfire', 'Stargazing'],
      price: '₹3,500/person',
      includes: ['Tent', 'Meals', 'Guide', 'Equipment'],
    },
    {
      name: 'Extended Expedition',
      duration: '4 days/3 nights',
      activities: ['Multi-day trek', 'Wildlife spotting', 'Fishing', 'Camping'],
      price: '₹8,000/person',
      includes: ['All meals', 'Camping gear', 'Guide', 'Permits', 'Transport'],
    },
  ];

  return (
    <section id="activities" className="py-20 bg-gradient-to-b from-emerald-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-emerald-600 font-semibold text-sm uppercase tracking-wider">
            Adventure Awaits
          </span>
          <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-900 mt-3 mb-6">
            Activities & Adventure Tourism
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            From peaceful nature walks to thrilling mountain treks, 
            Bungus Valley offers experiences for every type of traveler
          </p>
        </div>

        {/* Activities Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {activities.map((activity, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300"
            >
              {/* Icon Header */}
              <div className={`h-40 bg-gradient-to-br ${activity.color} flex items-center justify-center text-white`}>
                <div className="transform group-hover:scale-110 transition-transform duration-300">
                  {activity.icon}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-3">
                  {activity.title}
                </h3>
                <p className="text-gray-600 mb-4 leading-relaxed">
                  {activity.description}
                </p>

                {/* Info Grid */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="text-xs text-gray-500 mb-1">Best Time</div>
                    <div className="text-sm font-semibold text-gray-900">{activity.bestTime}</div>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <div className="text-xs text-gray-500 mb-1">Difficulty</div>
                    <div className="text-sm font-semibold text-gray-900">{activity.difficulty}</div>
                  </div>
                </div>

                {/* Highlights */}
                <div className="flex flex-wrap gap-2">
                  {activity.highlights.map((highlight, hIndex) => (
                    <span
                      key={hIndex}
                      className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-xs font-medium"
                    >
                      {highlight}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Adventure Packages */}
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-2xl p-8 md:p-12 text-white">
          <h3 className="text-2xl md:text-3xl font-bold text-center mb-8">
            Adventure Packages
          </h3>
          <div className="grid md:grid-cols-3 gap-6">
            {adventurePackages.map((pkg, index) => (
              <div
                key={index}
                className={`bg-white/10 backdrop-blur-sm rounded-xl p-6 ${
                  index === 1 ? 'ring-2 ring-emerald-400' : ''
                }`}
              >
                {index === 1 && (
                  <div className="flex items-center justify-center mb-4">
                    <Star className="h-5 w-5 text-emerald-400 fill-current mr-2" />
                    <span className="text-emerald-400 font-semibold text-sm">Most Popular</span>
                  </div>
                )}
                <h4 className="text-xl font-bold mb-2">{pkg.name}</h4>
                <div className="flex items-center mb-4">
                  <Zap className="h-4 w-4 mr-2" />
                  <span className="text-emerald-300">{pkg.duration}</span>
                </div>
                <div className="mb-4">
                  <div className="text-sm text-gray-400 mb-2">Activities:</div>
                  <div className="flex flex-wrap gap-2">
                    {pkg.activities.map((activity, aIndex) => (
                      <span key={aIndex} className="text-xs bg-white/20 px-2 py-1 rounded">
                        {activity}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="mb-4">
                  <div className="text-sm text-gray-400 mb-2">Includes:</div>
                  <div className="flex flex-wrap gap-2">
                    {pkg.includes.map((item, iIndex) => (
                      <span key={iIndex} className="text-xs bg-emerald-600/50 px-2 py-1 rounded">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="text-2xl font-bold text-emerald-300">{pkg.price}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Safety Notice */}
        <div className="mt-12 bg-amber-50 border border-amber-200 rounded-xl p-6">
          <div className="flex items-start">
            <AlertTriangle className="h-6 w-6 text-amber-600 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-amber-800 mb-2">Safety First</h4>
              <p className="text-amber-700 text-sm">
                Always inform local authorities about your trekking plans. Carry necessary safety 
                equipment, first aid kit, and sufficient water. Weather conditions can change rapidly 
                at high altitudes. Hire local guides for challenging treks.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function AlertTriangle({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
    </svg>
  );
}
