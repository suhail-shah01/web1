import { ArrowDown, MapPin, Calendar, Mountain, Tent } from 'lucide-react';

interface HeroProps {
  onNavigate: (section: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1593693399740-5a85c1c9c6b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"
          alt="Bungus Valley Kashmir"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-emerald-900/80" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
        {/* Badge */}
        <div className="inline-flex items-center space-x-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-6">
          <MapPin className="h-4 w-4 text-emerald-300" />
          <span className="text-white text-sm font-medium">Kupwara District, Jammu & Kashmir</span>
        </div>

        {/* Main Heading */}
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold font-serif text-white mb-6 leading-tight">
          Bungus Valley
          <span className="block text-2xl md:text-3xl lg:text-4xl font-normal mt-4 text-emerald-300">
            Kashmir's Hidden Paradise
          </span>
        </h1>

        {/* Description */}
        <p className="text-lg md:text-xl text-white/90 max-w-3xl mx-auto mb-8 leading-relaxed">
          Discover the untouched beauty of the Himalayas at 10,000 feet. 
          Experience pristine meadows, diverse wildlife, and adventure in one of 
          India's last unexplored treasures.
        </p>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
            <Mountain className="h-8 w-8 text-emerald-300 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">10,000+</div>
            <div className="text-sm text-white/70">Feet Altitude</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
            <div className="text-2xl font-bold text-white">300+</div>
            <div className="text-sm text-white/70">Sq Km Area</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
            <Calendar className="h-8 w-8 text-emerald-300 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">Apr-Sep</div>
            <div className="text-sm text-white/70">Best Season</div>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
            <Tent className="h-8 w-8 text-emerald-300 mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">2</div>
            <div className="text-sm text-white/70">Valleys (Bod & Lokut)</div>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button
            onClick={() => onNavigate('travel')}
            className="px-8 py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full font-semibold text-lg transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
          >
            Plan Your Visit
          </button>
          <button
            onClick={() => onNavigate('about')}
            className="px-8 py-4 bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white border-2 border-white/50 rounded-full font-semibold text-lg transition-all duration-300"
          >
            Explore Valley
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <button
          onClick={() => onNavigate('about')}
          className="text-white/70 hover:text-white transition-colors"
        >
          <ArrowDown className="h-8 w-8" />
        </button>
      </div>

      {/* Decorative Elements */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-emerald-50 to-transparent" />
    </section>
  );
}
