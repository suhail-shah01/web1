import { MapPin, Mountain, Trees, Droplets, Award } from 'lucide-react';

export default function About() {
  const features = [
    {
      icon: <MapPin className="h-6 w-6" />,
      title: 'Prime Location',
      description: 'Located in Kupwara district, 130 km from Srinagar in the Pir Panjal range',
    },
    {
      icon: <Mountain className="h-6 w-6" />,
      title: 'High Altitude',
      description: 'Situated at approximately 10,000 feet above sea level with breathtaking views',
    },
    {
      icon: <Trees className="h-6 w-6" />,
      title: 'Rich Biodiversity',
      description: 'Home to rare flora and fauna including snow leopards and musk deer',
    },
    {
      icon: <Droplets className="h-6 w-6" />,
      title: 'Pristine Streams',
      description: 'Crystal-clear mountain streams and rivers flow through the valley',
    },
  ];

  const stats = [
    { number: '300+', label: 'Square Kilometers', sublabel: 'Total Area' },
    { number: '10,000', label: 'Feet', sublabel: 'Above Sea Level' },
    { number: '130', label: 'Kilometers', sublabel: 'From Srinagar' },
    { number: '2', label: 'Valleys', sublabel: 'Bod & Lokut Bangus' },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-emerald-600 font-semibold text-sm uppercase tracking-wider">
            Discover Paradise
          </span>
          <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-900 mt-3 mb-6">
            About Bungus Valley
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            One of Kashmir's most pristine and untouched natural wonders, 
            where nature reigns supreme
          </p>
        </div>

        {/* Main Content */}
        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-3xl font-bold text-gray-900 mb-6">
              The Untouched Gem of the Himalayas
            </h3>
            <div className="space-y-4 text-gray-700 leading-relaxed">
              <p>
                Bungus Valley, nestled in the Kupwara district of Jammu and Kashmir, 
                stands as one of the most pristine and untouched natural wonders in the 
                Himalayas. This hidden paradise remains relatively undiscovered by 
                mainstream tourism, preserving its raw beauty and tranquility.
              </p>
              <p>
                The valley derives its name from Sanskrit words <strong>"Van"</strong> (forest) 
                and <strong>"Gus"</strong> (grass), perfectly encapsulating its lush green 
                meadows surrounded by dense coniferous forests. The landscape is divided 
                into two distinct parts: <strong>Bod Bangus (Big Bangus)</strong> and 
                <strong> Lokut Bangus (Small Bangus)</strong>, each offering unique 
                experiences for visitors.
              </p>
              <p>
                Surrounded by the majestic Rajwar and Mawar mountains in the east, 
                Shamasbury and Dajlungun peaks in the west, and Chowkibal and Karnah 
                Guli in the north, the valley forms a natural amphitheater of 
                breathtaking beauty.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid sm:grid-cols-2 gap-6 mt-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="flex-shrink-0 p-2 bg-emerald-100 rounded-lg text-emerald-600">
                    {feature.icon}
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{feature.title}</h4>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"
                alt="Bungus Valley Landscape"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-emerald-600 text-white p-6 rounded-xl shadow-lg">
              <Award className="h-12 w-12 mb-2" />
              <div className="text-2xl font-bold">Hidden Gem</div>
              <div className="text-emerald-200">Of Kashmir</div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-8 md:p-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center text-white">
                <div className="text-4xl md:text-5xl font-bold mb-2">{stat.number}</div>
                <div className="text-lg font-semibold">{stat.label}</div>
                <div className="text-emerald-200 text-sm">{stat.sublabel}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Etymology Box */}
        <div className="mt-16 bg-gray-50 rounded-2xl p-8 border border-gray-200">
          <div className="text-center">
            <h4 className="text-2xl font-bold text-gray-900 mb-4">Name Origin</h4>
            <p className="text-gray-700 max-w-2xl mx-auto">
              The name <strong>"Bungus"</strong> comes from the Sanskrit words 
              <span className="text-emerald-600 font-semibold"> "Van"</span> (meaning forest) 
              and <span className="text-emerald-600 font-semibold"> "Gus"</span> (meaning grass), 
              beautifully describing the valley's characteristic landscape of lush meadows 
              surrounded by dense forests.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
