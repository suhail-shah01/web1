import { useState } from 'react';
import { Camera, Mountain, Trees, Droplets, Tent, Bird } from 'lucide-react';

export default function Gallery() {
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { id: 'all', label: 'All Photos', icon: <Camera className="h-4 w-4" /> },
    { id: 'landscape', label: 'Landscapes', icon: <Mountain className="h-4 w-4" /> },
    { id: 'wildlife', label: 'Wildlife', icon: <Bird className="h-4 w-4" /> },
    { id: 'forests', label: 'Forests', icon: <Trees className="h-4 w-4" /> },
    { id: 'streams', label: 'Streams', icon: <Droplets className="h-4 w-4" /> },
    { id: 'camping', label: 'Camping', icon: <Tent className="h-4 w-4" /> },
  ];

  const galleryItems = [
    { id: 1, category: 'landscape', title: 'Valley View', image: 'https://images.unsplash.com/photo-1593693399740-5a85c1c9c6b4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 2, category: 'landscape', title: 'Mountain Peaks', image: 'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 3, category: 'forests', title: 'Coniferous Forest', image: 'https://images.unsplash.com/photo-1448375240586-882707db888b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 4, category: 'streams', title: 'Mountain Stream', image: 'https://images.unsplash.com/photo-1437482078695-73f5ca6c96e2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 5, category: 'camping', title: 'Camping Site', image: 'https://images.unsplash.com/photo-1478131143081-80f7f84ca84d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 6, category: 'landscape', title: 'Alpine Meadows', image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 7, category: 'wildlife', title: 'Wildlife Habitat', image: 'https://images.unsplash.com/photo-1484406566174-9da000ce6478?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 8, category: 'streams', title: 'Nallah Bungus', image: 'https://images.unsplash.com/photo-1415543901966-608a272346f8?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 9, category: 'forests', title: 'Forest Trail', image: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 10, category: 'camping', title: 'Night Camping', image: 'https://images.unsplash.com/photo-1523987355523-c7b5b0dd90a7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 11, category: 'landscape', title: 'Sunrise View', image: 'https://images.unsplash.com/photo-1505567745926-ba89000a25db?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
    { id: 12, category: 'wildlife', title: 'Bird Species', image: 'https://images.unsplash.com/photo-1452570053594-1b985d6ea890?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80' },
  ];

  const filteredItems = activeCategory === 'all' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === activeCategory);

  return (
    <section id="gallery" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-emerald-600 font-semibold text-sm uppercase tracking-wider">
            Visual Journey
          </span>
          <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-900 mt-3 mb-6">
            Photo Gallery
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Explore the breathtaking beauty of Bungus Valley through our curated collection
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`flex items-center px-4 py-2 rounded-full font-medium transition-all ${
                activeCategory === category.id
                  ? 'bg-emerald-600 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              <span className="mr-2">{category.icon}</span>
              {category.label}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="group relative aspect-square rounded-xl overflow-hidden cursor-pointer"
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="font-semibold">{item.title}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Gallery Note */}
        <div className="mt-12 text-center">
          <p className="text-gray-600">
            📸 Want to share your Bungus Valley photos? Tag us or email at{' '}
            <a href="mailto:photos@bungusvalley.com" className="text-emerald-600 hover:underline">
              photos@bungusvalley.com
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}
