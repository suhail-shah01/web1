import { Clock, MapPin, Tent, Mountain, Camera, Coffee, Moon, Sun } from 'lucide-react';

export default function Itinerary() {
  const itineraries = [
    {
      duration: '1 Day',
      title: 'Quick Escape',
      icon: <Sun className="h-6 w-6" />,
      color: 'from-yellow-500 to-orange-600',
      schedule: [
        { time: '6:00 AM', activity: 'Depart from Srinagar/Kupwara', icon: <MapPin className="h-4 w-4" /> },
        { time: '10:00 AM', activity: 'Arrive at Bungus Valley, Check-in', icon: <Tent className="h-4 w-4" /> },
        { time: '11:00 AM', activity: 'Nature walk and photography', icon: <Camera className="h-4 w-4" /> },
        { time: '1:00 PM', activity: 'Picnic lunch by the stream', icon: <Coffee className="h-4 w-4" /> },
        { time: '3:00 PM', activity: 'Explore Bod Bangus meadows', icon: <Mountain className="h-4 w-4" /> },
        { time: '5:00 PM', activity: 'Depart for return journey', icon: <MapPin className="h-4 w-4" /> },
      ],
      highlights: ['Quick valley experience', 'Perfect for day trippers', 'Photography focused'],
      difficulty: 'Easy',
    },
    {
      duration: '2 Days / 1 Night',
      title: 'Weekend Getaway',
      icon: <Moon className="h-6 w-6" />,
      color: 'from-emerald-500 to-teal-600',
      schedule: [
        { time: 'Day 1 - 7:00 AM', activity: 'Depart from Srinagar', icon: <MapPin className="h-4 w-4" /> },
        { time: 'Day 1 - 11:00 AM', activity: 'Arrive, Setup camp/Lunch', icon: <Tent className="h-4 w-4" /> },
        { time: 'Day 1 - 2:00 PM', activity: 'Trek to viewpoint', icon: <Mountain className="h-4 w-4" /> },
        { time: 'Day 1 - 6:00 PM', activity: 'Bonfire and stargazing', icon: <Moon className="h-4 w-4" /> },
        { time: 'Day 2 - 6:00 AM', activity: 'Sunrise photography', icon: <Sun className="h-4 w-4" /> },
        { time: 'Day 2 - 9:00 AM', activity: 'Explore Lokut Bangus', icon: <MapPin className="h-4 w-4" /> },
        { time: 'Day 2 - 2:00 PM', activity: 'Depart after lunch', icon: <MapPin className="h-4 w-4" /> },
      ],
      highlights: ['Overnight camping', 'Stargazing experience', 'Complete valley tour'],
      difficulty: 'Moderate',
    },
    {
      duration: '4 Days / 3 Nights',
      title: 'Complete Adventure',
      icon: <Mountain className="h-6 w-6" />,
      color: 'from-blue-500 to-indigo-600',
      schedule: [
        { time: 'Day 1', activity: 'Arrival, Setup camp, Valley exploration', icon: <Tent className="h-4 w-4" /> },
        { time: 'Day 2', activity: 'Trek to high altitude viewpoints, Wildlife spotting', icon: <Mountain className="h-4 w-4" /> },
        { time: 'Day 3', activity: 'Visit Lokut Bangus, Fishing, Photography', icon: <Camera className="h-4 w-4" /> },
        { time: 'Day 4', activity: 'Morning nature walk, Departure', icon: <MapPin className="h-4 w-4" /> },
      ],
      highlights: ['Immersive experience', 'Multiple treks', 'Wildlife observation', 'All activities included'],
      difficulty: 'Moderate to Difficult',
    },
  ];

  const packingList = [
    { category: 'Clothing', items: ['Warm jacket', 'Thermal wear', 'Raincoat', 'Comfortable trekking shoes', 'Hat/Cap'] },
    { category: 'Essentials', items: ['First aid kit', 'Sunscreen', 'Sunglasses', 'Water bottle', 'Power bank'] },
    { category: 'Camping', items: ['Sleeping bag', 'Tent (if not renting)', 'Flashlight', 'Extra batteries'] },
    { category: 'Food', items: ['Energy bars', 'Dry fruits', 'Instant noodles', 'Tea/Coffee'] },
    { category: 'Documents', items: ['ID proof', 'Permits (if required)', 'Emergency contacts', 'Cash'] },
  ];

  return (
    <section id="itinerary" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-emerald-600 font-semibold text-sm uppercase tracking-wider">
            Plan Your Trip
          </span>
          <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-900 mt-3 mb-6">
            Suggested Itineraries
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose the perfect itinerary based on your time and adventure level
          </p>
        </div>

        {/* Itinerary Cards */}
        <div className="grid lg:grid-cols-3 gap-8 mb-16">
          {itineraries.map((itinerary, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl overflow-hidden shadow-lg border border-gray-200 hover:shadow-xl transition-shadow"
            >
              {/* Header */}
              <div className={`bg-gradient-to-r ${itinerary.color} p-6 text-white`}>
                <div className="flex items-center justify-between mb-2">
                  {itinerary.icon}
                  <span className="text-sm font-medium bg-white/20 px-3 py-1 rounded-full">
                    {itinerary.duration}
                  </span>
                </div>
                <h3 className="text-2xl font-bold">{itinerary.title}</h3>
                <div className="mt-4 flex flex-wrap gap-2">
                  {itinerary.highlights.map((highlight, hIndex) => (
                    <span key={hIndex} className="text-xs bg-white/20 px-2 py-1 rounded">
                      {highlight}
                    </span>
                  ))}
                </div>
              </div>

              {/* Schedule */}
              <div className="p-6">
                <h4 className="font-bold text-gray-900 mb-4 flex items-center">
                  <Clock className="h-5 w-5 mr-2 text-emerald-600" />
                  Schedule
                </h4>
                <div className="space-y-3">
                  {itinerary.schedule.map((item, sIndex) => (
                    <div key={sIndex} className="flex items-start">
                      <div className="flex-shrink-0 w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 mr-3">
                        {item.icon}
                      </div>
                      <div>
                        <div className="text-sm font-semibold text-emerald-600">{item.time}</div>
                        <div className="text-gray-700">{item.activity}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-6 pt-4 border-t border-gray-200">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Difficulty</span>
                    <span className="font-semibold text-gray-900">{itinerary.difficulty}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Packing List */}
        <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Essential Packing List
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
            {packingList.map((category, index) => (
              <div key={index} className="bg-white rounded-xl p-4 shadow">
                <h4 className="font-bold text-emerald-700 mb-3">{category.category}</h4>
                <ul className="space-y-2">
                  {category.items.map((item, iIndex) => (
                    <li key={iIndex} className="flex items-center text-sm text-gray-700">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full mr-2 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Custom Itinerary CTA */}
        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">
            Want a customized itinerary based on your interests and group size?
          </p>
          <button className="px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full font-semibold transition-colors">
            Contact Us for Custom Plans
          </button>
        </div>
      </div>
    </section>
  );
}
