import { Plane, Car, Train, MapPin, AlertTriangle, CheckCircle } from 'lucide-react';

export default function TravelGuide() {
  const transportOptions = [
    {
      icon: <Plane className="h-8 w-8" />,
      title: 'By Air',
      subtitle: 'Nearest Airport',
      details: 'Srinagar International Airport (SXR)',
      distance: '90 km from Kupwara, 130 km from Bungus Valley',
      info: 'Regular flights from Delhi, Mumbai, and other major cities. From Srinagar, hire a taxi or take a bus to Kupwara.',
    },
    {
      icon: <Car className="h-8 w-8" />,
      title: 'By Road',
      subtitle: 'Most Popular Route',
      details: 'Two Main Routes Available',
      distance: 'Route 1: 42 km from Kupwara | Route 2: 29 km from Handwara',
      info: 'Well-connected by road. Hire a taxi from Srinagar or take local buses to Kupwara/Handwara, then proceed to the valley.',
    },
    {
      icon: <Train className="h-8 w-8" />,
      title: 'By Train',
      subtitle: 'Nearest Railway Station',
      details: 'Baramulla Railway Station',
      distance: '64 km from Kupwara district',
      info: 'Connected to Srinagar via the Kashmir Railway. From Baramulla, take a taxi or bus to Kupwara.',
    },
  ];

  const routeInfo = [
    {
      route: 'Srinagar → Kupwara → Bungus Valley',
      distance: '130 km total',
      duration: '4-5 hours',
      difficulty: 'Moderate',
    },
    {
      route: 'Srinagar → Handwara → Bungus Valley',
      distance: '120 km total',
      duration: '3.5-4 hours',
      difficulty: 'Moderate',
    },
  ];

  const tips = [
    'Carry valid ID proof for security checkpoints',
    'Check weather conditions before traveling',
    'Keep emergency contact numbers handy',
    'Inform someone about your travel plans',
    'Carry sufficient cash (ATMs limited in remote areas)',
    'Respect local customs and traditions',
  ];

  const warnings = [
    'Winter months (Dec-Mar) may have road closures due to heavy snowfall',
    'Mobile network connectivity is limited in the valley',
    'Medical facilities are basic; carry necessary medications',
    'Permit may be required for certain areas - check locally',
  ];

  return (
    <section id="travel" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-emerald-600 font-semibold text-sm uppercase tracking-wider">
            Plan Your Journey
          </span>
          <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-900 mt-3 mb-6">
            Travel Guide & Routes
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Everything you need to know to reach Bungus Valley safely and comfortably
          </p>
        </div>

        {/* Transportation Options */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {transportOptions.map((option, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-gray-50 to-white rounded-2xl p-6 border border-gray-200 hover:shadow-lg transition-shadow"
            >
              <div className="w-16 h-16 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600 mb-4">
                {option.icon}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-1">{option.title}</h3>
              <p className="text-emerald-600 font-medium mb-3">{option.subtitle}</p>
              <div className="space-y-3">
                <div>
                  <div className="text-sm text-gray-500">Details</div>
                  <div className="font-semibold text-gray-900">{option.details}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Distance</div>
                  <div className="font-semibold text-gray-900">{option.distance}</div>
                </div>
                <p className="text-gray-600 text-sm leading-relaxed">{option.info}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Route Information */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 rounded-2xl p-8 md:p-12 mb-16 text-white">
          <h3 className="text-2xl md:text-3xl font-bold text-center mb-8">
            Popular Routes from Srinagar
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            {routeInfo.map((route, index) => (
              <div key={index} className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
                <div className="flex items-center mb-4">
                  <MapPin className="h-6 w-6 mr-3" />
                  <h4 className="text-lg font-bold">{route.route}</h4>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-emerald-200 text-sm">Total Distance</div>
                    <div className="font-semibold">{route.distance}</div>
                  </div>
                  <div>
                    <div className="text-emerald-200 text-sm">Duration</div>
                    <div className="font-semibold">{route.duration}</div>
                  </div>
                  <div>
                    <div className="text-emerald-200 text-sm">Difficulty</div>
                    <div className="font-semibold">{route.difficulty}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Travel Tips & Warnings */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Tips */}
          <div className="bg-blue-50 rounded-2xl p-8 border border-blue-200">
            <div className="flex items-center mb-6">
              <CheckCircle className="h-8 w-8 text-blue-600 mr-3" />
              <h3 className="text-2xl font-bold text-gray-900">Travel Tips</h3>
            </div>
            <ul className="space-y-3">
              {tips.map((tip, index) => (
                <li key={index} className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Warnings */}
          <div className="bg-amber-50 rounded-2xl p-8 border border-amber-200">
            <div className="flex items-center mb-6">
              <AlertTriangle className="h-8 w-8 text-amber-600 mr-3" />
              <h3 className="text-2xl font-bold text-gray-900">Important Information</h3>
            </div>
            <ul className="space-y-3">
              {warnings.map((warning, index) => (
                <li key={index} className="flex items-start">
                  <AlertTriangle className="h-5 w-5 text-amber-600 mr-3 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{warning}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Distance Chart */}
        <div className="mt-16 bg-gray-50 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Distance from Major Cities
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">From</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Distance</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Travel Time</th>
                  <th className="text-left py-3 px-4 font-semibold text-gray-700">Best Route</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4 text-gray-900">Srinagar</td>
                  <td className="py-3 px-4 text-gray-700">130 km</td>
                  <td className="py-3 px-4 text-gray-700">4-5 hours</td>
                  <td className="py-3 px-4 text-gray-700">Via Kupwara</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4 text-gray-900">Jammu</td>
                  <td className="py-3 px-4 text-gray-700">350 km</td>
                  <td className="py-3 px-4 text-gray-700">8-9 hours</td>
                  <td className="py-3 px-4 text-gray-700">Via Srinagar</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4 text-gray-900">Leh</td>
                  <td className="py-3 px-4 text-gray-700">450 km</td>
                  <td className="py-3 px-4 text-gray-700">10-11 hours</td>
                  <td className="py-3 px-4 text-gray-700">Via Srinagar</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-gray-900">Delhi</td>
                  <td className="py-3 px-4 text-gray-700">850 km</td>
                  <td className="py-3 px-4 text-gray-700">Fly to Srinagar + 5 hrs</td>
                  <td className="py-3 px-4 text-gray-700">Flight + Road</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
