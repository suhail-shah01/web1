import { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const faqs = [
    {
      question: 'What is the best time to visit Bungus Valley?',
      answer: 'The best time to visit Bungus Valley is from April to September when the weather is pleasant (10°C to 25°C) and the valley is accessible. Spring (April-June) offers blooming wildflowers, while summer (July-September) provides lush green landscapes. Winter months (December-March) experience heavy snowfall and the valley may be inaccessible.',
      category: 'Planning',
    },
    {
      question: 'How do I reach Bungus Valley?',
      answer: 'Bungus Valley can be reached via two main routes: (1) From Srinagar → Kupwara (90 km) → Bungus Valley (42 km), or (2) From Srinagar → Handwara → Bungus Valley (29 km). The nearest airport is Srinagar International Airport (130 km), and the nearest railway station is Baramulla (64 km from Kupwara). Taxis and local buses are available from Srinagar.',
      category: 'Transport',
    },
    {
      question: 'Is Bungus Valley safe for tourists?',
      answer: 'Yes, Bungus Valley is generally safe for tourists. However, it\'s recommended to travel in groups, inform local authorities about your plans, and hire local guides for treks. Check current travel advisories before planning your trip and always carry valid ID proof for security checkpoints.',
      category: 'Safety',
    },
    {
      question: 'What accommodation options are available?',
      answer: 'Accommodation options include camping sites in the valley (₹500-1,500/night), homestays in nearby villages (₹1,000-2,500/night), and guest houses in Kupwara/Handwara towns (₹1,500-3,500/night). Advance booking is recommended during peak season (May-June). Basic amenities are available, but don\'t expect luxury facilities.',
      category: 'Stay',
    },
    {
      question: 'Do I need any permits to visit Bungus Valley?',
      answer: 'Generally, no special permits are required for Indian tourists. However, certain areas within the valley may require local permits. Foreign nationals should check current regulations with the tourism office in Srinagar or Kupwara before visiting. Always carry valid government ID proof.',
      category: 'Permits',
    },
    {
      question: 'What activities can I do in Bungus Valley?',
      answer: 'Popular activities include trekking, camping, bird watching, trout fishing, photography, nature walks, and wildlife spotting. Adventure packages are available ranging from day trips (₹1,500) to multi-day expeditions (₹8,000). Local guides can be hired for specialized activities.',
      category: 'Activities',
    },
    {
      question: 'Is mobile network available in the valley?',
      answer: 'Mobile network connectivity is limited and intermittent in Bungus Valley. Major networks like BSNL, Airtel, and Jio may work in some areas, but don\'t rely on constant connectivity. Inform family/friends about your travel plans before entering the valley and carry a power bank for your devices.',
      category: 'Connectivity',
    },
    {
      question: 'Are there medical facilities available?',
      answer: 'Basic medical facilities are available in Kupwara and Handwara towns. The valley itself has no medical facilities, so carry a comprehensive first-aid kit and any necessary medications. For serious medical emergencies, you\'ll need to travel to Kupwara or Srinagar. Travel insurance is recommended.',
      category: 'Health',
    },
    {
      question: 'What should I pack for Bungus Valley?',
      answer: 'Essential items include: warm clothing (even in summer), comfortable trekking shoes, raincoat, first-aid kit, sunscreen, sunglasses, water bottle, power bank, flashlight, sleeping bag (for camping), cash (ATMs are limited), and valid ID proof. Pack light but prepare for variable weather conditions.',
      category: 'Packing',
    },
    {
      question: 'Can I visit Bungus Valley in winter?',
      answer: 'Winter visits (December-March) are challenging due to heavy snowfall and road closures. The valley transforms into a winter wonderland but is only accessible to experienced trekkers with proper equipment. Most tourism activities are suspended. Spring (April onwards) is recommended for regular tourists.',
      category: 'Seasons',
    },
    {
      question: 'Is Bungus Valley suitable for families with children?',
      answer: 'Yes, Bungus Valley is family-friendly. Easy nature walks, picnicking spots, and camping experiences are suitable for children. However, ensure children are supervised, carry necessary medications, and choose easier trekking routes. The valley\'s peaceful environment is great for family bonding.',
      category: 'Family',
    },
    {
      question: 'What about food and dining options?',
      answer: 'Limited food options are available in the valley. Some camping sites and homestays provide meals. It\'s recommended to carry your own food supplies, especially if camping. Nearby towns (Kupwara, Handwara) have restaurants. Try local Kashmiri cuisine when available.',
      category: 'Food',
    },
  ];

  const categories = ['All', ...Array.from(new Set(faqs.map(faq => faq.category)))];
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredFaqs = activeCategory === 'All' 
    ? faqs 
    : faqs.filter(faq => faq.category === activeCategory);

  return (
    <section id="faq" className="py-20 bg-gradient-to-b from-emerald-50 to-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-emerald-600 font-semibold text-sm uppercase tracking-wider">
            Got Questions?
          </span>
          <h2 className="text-4xl md:text-5xl font-bold font-serif text-gray-900 mt-3 mb-6">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-gray-600">
            Find answers to common questions about visiting Bungus Valley
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                activeCategory === category
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {filteredFaqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white rounded-xl border border-gray-200 overflow-hidden hover:shadow-md transition-shadow"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors"
              >
                <div className="flex items-center">
                  <HelpCircle className="h-5 w-5 text-emerald-600 mr-3 flex-shrink-0" />
                  <span className="font-semibold text-gray-900 pr-4">{faq.question}</span>
                </div>
                {openIndex === index ? (
                  <ChevronUp className="h-5 w-5 text-gray-400 flex-shrink-0" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-400 flex-shrink-0" />
                )}
              </button>
              {openIndex === index && (
                <div className="px-6 pb-4">
                  <div className="pl-8 text-gray-600 leading-relaxed">
                    {faq.answer}
                  </div>
                  <div className="pl-8 mt-3">
                    <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded">
                      {faq.category}
                    </span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Contact CTA */}
        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">
            Still have questions? We're here to help!
          </p>
          <a
            href="#contact"
            className="inline-flex items-center px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full font-semibold transition-colors"
          >
            Contact Us
          </a>
        </div>
      </div>
    </section>
  );
}
