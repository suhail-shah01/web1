import { Mountain, MapPin, Phone, Mail, Heart } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { label: 'Home', href: '#home' },
    { label: 'About Valley', href: '#about' },
    { label: 'Attractions', href: '#attractions' },
    { label: 'Travel Guide', href: '#travel' },
    { label: 'Activities', href: '#activities' },
    { label: 'Stay & Camping', href: '#stay' },
  ];

  const resources = [
    { label: 'Photo Gallery', href: '#gallery' },
    { label: 'Itinerary Plans', href: '#itinerary' },
    { label: 'FAQ', href: '#faq' },
    { label: 'Contact Us', href: '#contact' },
    { label: 'Site Map', href: '#sitemap' },
  ];

  const legal = [
    { label: 'Privacy Policy', href: '#' },
    { label: 'Terms of Service', href: '#' },
    { label: 'Disclaimer', href: '#' },
    { label: 'Cookie Policy', href: '#' },
  ];

  return (
    <footer className="bg-gray-900 text-white">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Section */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="p-2 bg-emerald-600 rounded-lg">
                <Mountain className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold font-serif">Bungus Valley</h3>
                <p className="text-xs text-emerald-400">Kashmir's Hidden Paradise</p>
              </div>
            </div>
            <p className="text-gray-400 mb-6 leading-relaxed">
              Discover the untouched beauty of the Himalayas at 10,000 feet. 
              Experience pristine meadows, diverse wildlife, and adventure in 
              one of India's last unexplored treasures.
            </p>
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <MapPin className="h-4 w-4" />
              <span>Kupwara District, Jammu & Kashmir</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-emerald-400 transition-colors text-sm"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources */}
          <div>
            <h4 className="text-lg font-bold mb-6">Resources</h4>
            <ul className="space-y-3">
              {resources.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-400 hover:text-emerald-400 transition-colors text-sm"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact & Newsletter */}
          <div>
            <h4 className="text-lg font-bold mb-6">Contact Us</h4>
            <div className="space-y-4 mb-6">
              <div className="flex items-center space-x-3 text-gray-400">
                <Phone className="h-4 w-4" />
                <span className="text-sm">+91 9876543210</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-400">
                <Mail className="h-4 w-4" />
                <span className="text-sm">info@bungusvalley.com</span>
              </div>
            </div>
            
            {/* Newsletter */}
            <div>
              <h5 className="text-sm font-semibold mb-3">Subscribe for Updates</h5>
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-l-lg text-sm text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 rounded-r-lg text-sm font-medium transition-colors">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Site Map Section */}
      <div id="sitemap" className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <h4 className="text-lg font-bold mb-6 text-center">Site Map</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 text-center">
            {['Home', 'About', 'Attractions', 'Travel Guide', 'Activities', 'Stay', 'Gallery', 'Itinerary', 'FAQ', 'Contact', 'Privacy', 'Terms'].map((item, index) => (
              <a
                key={index}
                href={`#${item.toLowerCase().replace(' ', '-')}`}
                className="text-gray-400 hover:text-emerald-400 transition-colors text-sm"
              >
                {item}
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            {/* Copyright */}
            <div className="text-gray-400 text-sm text-center md:text-left">
              <p>© {currentYear} Bungus Valley Tourism. All rights reserved.</p>
              <p className="mt-1">
                Official Domain: <span className="text-emerald-400">bungusvalley.com</span>
              </p>
            </div>

            {/* Made with Love */}
            <div className="flex items-center space-x-2 text-gray-400 text-sm">
              <span>Made with</span>
              <Heart className="h-4 w-4 text-red-500 fill-current" />
              <span>in Kashmir</span>
            </div>

            {/* Legal Links */}
            <div className="flex space-x-6">
              {legal.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  className="text-gray-400 hover:text-emerald-400 transition-colors text-sm"
                >
                  {link.label}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Tourism Promotion Banner */}
      <div className="bg-emerald-900/50 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-emerald-300 text-sm">
            🏔️ Promoting sustainable tourism in Jammu & Kashmir | 
            Support local communities | Preserve natural heritage
          </p>
        </div>
      </div>
    </footer>
  );
}
