# 🚀 Deploy Bungus Valley Website to GitHub Pages

## Complete Step-by-Step Guide

Follow these instructions to publish your website on GitHub Pages for **FREE**!

---

## 📋 Prerequisites

Before you begin, make sure you have:
- ✅ A GitHub account (create one at github.com if you don't have)
- ✅ Git installed on your computer
- ✅ Your website code ready (you have this!)

---

## 🎯 Step-by-Step Deployment Process

### **Step 1: Initialize Git Repository**

Open your terminal/command prompt in the project folder and run:

```bash
# Initialize git repository
git init

# Add all files to git
git add .

# Create first commit
git commit -m "Initial commit - Bungus Valley Website"
```

---

### **Step 2: Create GitHub Repository**

1. Go to **https://github.com**
2. Click the **"+"** icon in the top right
3. Select **"New repository"**
4. Fill in the details:
   - **Repository name**: `bungus-valley` (or `bungusvalley`)
   - **Description**: "Official website for Bungus Valley Kashmir Tourism"
   - **Visibility**: Public (required for GitHub Pages)
   - **DO NOT** initialize with README (we already have code)
5. Click **"Create repository"**

---

### **Step 3: Connect Local Repository to GitHub**

GitHub will show you commands to connect. Run these in your terminal:

```bash
# Add your GitHub repository as remote
# Replace YOUR_USERNAME with your actual GitHub username
git remote add origin https://github.com/YOUR_USERNAME/bungus-valley.git

# Verify it's connected
git remote -v
```

You should see:
```
origin  https://github.com/YOUR_USERNAME/bungus-valley.git (fetch)
origin  https://github.com/YOUR_USERNAME/bungus-valley.git (push)
```

---

### **Step 4: Push Code to GitHub**

```bash
# Push your code to GitHub
git branch -M main
git push -u origin main
```

Your code is now on GitHub! 🎉

---

### **Step 5: Deploy to GitHub Pages**

Now deploy the built website:

```bash
# This will build and deploy automatically
npm run deploy
```

What this does:
1. Runs `npm run build` (creates optimized production files)
2. Deploys the `dist` folder to a `gh-pages` branch
3. GitHub Pages will serve from this branch

---

### **Step 6: Configure GitHub Pages**

1. Go to your repository on GitHub: `https://github.com/YOUR_USERNAME/bungus-valley`
2. Click **"Settings"** tab
3. Click **"Pages"** in the left sidebar
4. Under **"Source"**, select:
   - **Branch**: `gh-pages`
   - **Folder**: `/ (root)`
5. Click **"Save"**

---

### **Step 7: Wait for Deployment**

GitHub will build and deploy your site. This takes 2-5 minutes.

To check status:
1. Go to **Settings > Pages**
2. You'll see a message like: "Your site is live at..."
3. Or check **Actions** tab to see deployment progress

---

### **Step 8: Access Your Live Website**

Your website will be live at:

```
https://YOUR_USERNAME.github.io/bungus-valley/
```

🎉 **Congratulations! Your website is now live!**

---

## 🔗 Custom Domain (bungusvalley.com)

If you want to use your custom domain **bungusvalley.com**:

### **Option A: Using GitHub Pages with Custom Domain**

1. Go to **Settings > Pages** in your GitHub repository
2. Under **"Custom domain"**, enter: `bungusvalley.com`
3. Click **"Save"**
4. GitHub will show you DNS records to configure

### **DNS Configuration at Your Domain Registrar**

Go to where you bought bungusvalley.com (GoDaddy, Namecheap, etc.) and add:

**For apex domain (bungusvalley.com):**
```
Type: A
Name: @
Value: 185.199.108.153
```

```
Type: A
Name: @
Value: 185.199.109.153
```

```
Type: A
Name: @
Value: 185.199.110.153
```

```
Type: A
Name: @
Value: 185.199.111.153
```

**For www subdomain (www.bungusvalley.com):**
```
Type: CNAME
Name: www
Value: YOUR_USERNAME.github.io
```

### **Enable HTTPS**

After DNS propagates (can take 24-48 hours):
1. Go back to **Settings > Pages**
2. Check **"Enforce HTTPS"** (appears after DNS is configured)
3. Your site will be available at `https://bungusvalley.com`

---

## 🔄 Updating Your Website

Whenever you make changes:

```bash
# 1. Save your changes in code

# 2. Commit changes
git add .
git commit -m "Updated website content"

# 3. Push to GitHub
git push origin main

# 4. Deploy to GitHub Pages
npm run deploy
```

Changes will be live in 2-5 minutes!

---

## ⚙️ Update package.json for Your Repository

**IMPORTANT**: Update the `homepage` field in `package.json`:

1. Open `package.json`
2. Find this line:
   ```json
   "homepage": "https://yourusername.github.io/bungus-valley",
   ```
3. Replace `yourusername` with your actual GitHub username:
   ```json
   "homepage": "https://YOUR_USERNAME.github.io/bungus-valley",
   ```

This ensures all assets load correctly.

---

## 🎨 Update Vite Config for GitHub Pages

Create or update `vite.config.ts`:

```typescript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from 'tailwindcss'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  base: '/bungus-valley/', // Replace with your repo name
})
```

**Important**: Change `/bungus-valley/` to match your repository name exactly!

---

## 📱 Quick Deployment Commands Summary

```bash
# Initial Setup
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/YOUR_USERNAME/bungus-valley.git
git branch -M main
git push -u origin main

# Deploy to GitHub Pages
npm run deploy

# For Future Updates
git add .
git commit -m "Update description"
git push origin main
npm run deploy
```

---

## 🔍 Troubleshooting

### **Problem: Website shows but styles/images don't load**

**Solution**: Update `vite.config.ts` with correct base path:
```typescript
base: '/bungus-valley/', // Must match your repo name
```

Then rebuild and redeploy:
```bash
npm run build
npm run deploy
```

---

### **Problem: 404 Error on GitHub Pages**

**Solutions**:
1. Wait 2-5 minutes (GitHub needs time to build)
2. Check **Actions** tab for build errors
3. Ensure `gh-pages` branch exists
4. Verify Settings > Pages is configured for `gh-pages` branch

---

### **Problem: Custom Domain Not Working**

**Solutions**:
1. Wait 24-48 hours for DNS propagation
2. Double-check DNS records at your domain registrar
3. Ensure custom domain is set in GitHub Pages settings
4. Try clearing browser cache

---

### **Problem: Deployment Fails**

**Check**:
1. Build works: `npm run build` (should complete without errors)
2. You have `gh-pages` package installed
3. You're on the `main` branch when running deploy

**Fix**:
```bash
npm install gh-pages --save-dev
npm run build
npm run deploy
```

---

## 📊 GitHub Pages Limits

**Free Tier Includes**:
- ✅ Unlimited public repositories
- ✅ Free hosting for static sites
- ✅ Custom domain support
- ✅ HTTPS/SSL certificate
- ✅ 100GB bandwidth/month
- ✅ 1GB storage per repository

**Perfect for your tourism website!**

---

## 🎯 Alternative: GitHub Pages with Custom Action

For more control, create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          
      - name: Install dependencies
        run: npm ci
        
      - name: Build
        run: npm run build
        
      - name: Setup Pages
        uses: actions/configure-pages@v4
        
      - name: Upload artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: './dist'
          
  deploy:
    environment:
      name: github-pages
      url: ${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    needs: build
    steps:
      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
```

This automatically deploys on every push to main!

---

## ✅ Deployment Checklist

Before going live:

- [ ] Git repository initialized
- [ ] Code committed to GitHub
- [ ] `package.json` homepage updated
- [ ] `vite.config.ts` base path updated
- [ ] `npm run deploy` completed successfully
- [ ] GitHub Pages configured for `gh-pages` branch
- [ ] Website accessible at GitHub Pages URL
- [ ] (Optional) Custom domain configured
- [ ] (Optional) HTTPS enabled
- [ ] Tested on mobile and desktop
- [ ] All links working

---

## 🎉 You're Done!

Your Bungus Valley website is now:
- ✅ Live on GitHub Pages
- ✅ Free to host
- ✅ Accessible worldwide
- ✅ Ready for visitors
- ✅ Easy to update

**Live URL**: `https://YOUR_USERNAME.github.io/bungus-valley/`

**Custom Domain** (if configured): `https://bungusvalley.com`

---

## 📞 Need Help?

### **GitHub Resources**:
- [GitHub Pages Documentation](https://pages.github.com/)
- [GitHub Pages Guide](https://docs.github.com/en/pages)
- [GitHub Community](https://github.community/)

### **Check Deployment Status**:
1. Go to your repository
2. Click **"Actions"** tab
3. See build/deployment status

### **View Your Site**:
1. Go to **Settings > Pages**
2. Click the live URL

---

## 🔄 Regular Maintenance

### **Weekly**:
- Check for broken links
- Review analytics (if set up)
- Check contact form submissions

### **Monthly**:
- Update content if needed
- Add new photos
- Check mobile responsiveness
- Update dependencies: `npm update`

### **To Update Dependencies**:
```bash
npm update
git add .
git commit -m "Update dependencies"
git push
npm run deploy
```

---

**🏔️ Your Bungus Valley website is now live and ready to welcome tourists from around the world!**

*Good luck with your tourism business!*