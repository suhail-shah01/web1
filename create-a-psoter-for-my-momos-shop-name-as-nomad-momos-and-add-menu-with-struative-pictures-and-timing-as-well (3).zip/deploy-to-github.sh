#!/bin/bash

# 🚀 Bungus Valley - GitHub Pages Deployment Script
# This script automates the deployment process to GitHub Pages

echo "🏔️  Bungus Valley Website - GitHub Pages Deployment"
echo "===================================================="
echo ""

# Check if git is installed
if ! command -v git &> /dev/null
then
    echo "❌ Git is not installed. Please install Git first."
    echo "   Visit: https://git-scm.com/downloads"
    exit 1
fi

echo "✅ Git is installed"
echo ""

# Check if this is a git repository
if [ ! -d .git ]; then
    echo "📦 Initializing Git repository..."
    git init
    echo "✅ Git repository initialized"
    echo ""
fi

# Get GitHub username
echo "👤 Enter your GitHub username:"
read -p "Username: " GITHUB_USERNAME

# Get repository name
echo ""
echo "📁 Enter repository name (e.g., bungus-valley):"
read -p "Repository: " REPO_NAME

echo ""
echo "🔗 Setting up repository remote..."
git remote add origin https://github.com/$GITHUB_USERNAME/$REPO_NAME.git 2>/dev/null || echo "Remote already exists"
echo "✅ Remote configured"
echo ""

# Update package.json with correct homepage
echo "📝 Updating package.json..."
if [ -f package.json ]; then
    # Create backup
    cp package.json package.json.backup
    
    # Update homepage field
    if grep -q '"homepage"' package.json; then
        sed -i.bak "s|\"homepage\": \"[^\"]*\"|\"homepage\": \"https://$GITHUB_USERNAME.github.io/$REPO_NAME\"|g" package.json
    else
        # Add homepage after version field
        sed -i.bak "s/\"version\": \"[^\"]*\",/\"version\": \"0.0.0\",\n  \"homepage\": \"https:\/\/$GITHUB_USERNAME.github.io\/$REPO_NAME\",/g" package.json
    fi
    
    rm -f package.json.bak
    echo "✅ package.json updated"
else
    echo "❌ package.json not found!"
    exit 1
fi
echo ""

# Update vite.config.ts with base path
echo "⚙️  Updating vite.config.ts..."
if [ -f vite.config.ts ]; then
    cp vite.config.ts vite.config.ts.backup
    
    if grep -q "base:" vite.config.ts; then
        sed -i.bak "s|base: '[^']*'|base: './'|g" vite.config.ts
        sed -i.bak "s|base: \"[^\"]*\"|base: './'|g" vite.config.ts
    else
        # Add base after plugins
        sed -i.bak "s|plugins: \[react(), tailwindcss(), viteSingleFile()\],|plugins: [react(), tailwindcss(), viteSingleFile()],\n  base: './',|g" vite.config.ts
    fi
    
    rm -f vite.config.ts.bak
    echo "✅ vite.config.ts updated"
else
    echo "❌ vite.config.ts not found!"
    exit 1
fi
echo ""

# Install dependencies if needed
echo "📦 Checking dependencies..."
if [ ! -d node_modules ] || [ ! -f package-lock.json ]; then
    echo "Installing dependencies..."
    npm install
else
    echo "✅ Dependencies already installed"
fi
echo ""

# Build the project
echo "🔨 Building project..."
npm run build
if [ $? -ne 0 ]; then
    echo "❌ Build failed! Please fix errors and try again."
    exit 1
fi
echo "✅ Build successful"
echo ""

# Add all files to git
echo "📂 Adding files to git..."
git add .
echo "✅ Files added"
echo ""

# Create commit
echo "💾 Creating commit..."
git commit -m "Deploy Bungus Valley website to GitHub Pages" || git commit -m "Initial commit"
echo "✅ Commit created"
echo ""

# Set main branch
echo "🌿 Setting main branch..."
git branch -M main
echo "✅ Main branch set"
echo ""

# Push to GitHub
echo "🚀 Pushing to GitHub..."
git push -u origin main
if [ $? -ne 0 ]; then
    echo "⚠️  Push failed. You may need to authenticate with GitHub."
    echo "   Follow the instructions above or use a Personal Access Token."
    echo ""
fi
echo ""

# Deploy to gh-pages
echo "🌐 Deploying to GitHub Pages..."
npm run deploy
if [ $? -ne 0 ]; then
    echo "❌ Deployment failed! Please check errors above."
    exit 1
fi
echo "✅ Deployment successful!"
echo ""

# Show final information
echo "===================================================="
echo "🎉 DEPLOYMENT COMPLETE!"
echo "===================================================="
echo ""
echo "📍 Your website will be live at:"
echo "   https://$GITHUB_USERNAME.github.io/$REPO_NAME/"
echo ""
echo "⏱️  Please wait 2-5 minutes for GitHub to build and deploy."
echo ""
echo "📋 Next Steps:"
echo "   1. Go to: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo "   2. Click Settings > Pages"
echo "   3. Ensure Source is set to 'gh-pages' branch"
echo "   4. Wait for deployment to complete"
echo "   5. Visit your live website!"
echo ""
echo "🔗 For custom domain (bungusvalley.com):"
echo "   - Add DNS records at your domain registrar"
echo "   - Configure in Settings > Pages > Custom domain"
echo "   - See GITHUB_PAGES_DEPLOYMENT.md for details"
echo ""
echo "🔄 To update in the future:"
echo "   git add ."
echo "   git commit -m \"Your update message\""
echo "   git push"
echo "   npm run deploy"
echo ""
echo "===================================================="
echo "🏔️  Good luck with Bungus Valley Tourism!"
echo "===================================================="
