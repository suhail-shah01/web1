# 🚀 Quick Start: Deploy to GitHub Pages in 5 Minutes

## The Fastest Way to Get Your Website Live!

---

## ⚡ Super Quick Method (5 Commands)

Open your terminal/command prompt in the project folder and run:

### **For Mac/Linux:**
```bash
# 1. Initialize git
git init

# 2. Add all files
git add .

# 3. Create first commit
git commit -m "Initial commit"

# 4. Deploy to GitHub Pages (one command!)
npx gh-pages -d dist

# 5. Done! Now configure on GitHub (see below)
```

### **For Windows:**
```cmd
git init
git add .
git commit -m "Initial commit"
npx gh-pages -d dist
```

---

## 📋 Then Do This on GitHub:

1. **Create Repository:**
   - Go to https://github.com
   - Click "+" → "New repository"
   - Name it: `bungus-valley`
   - Make it Public
   - Click "Create repository"

2. **Push Your Code:**
   ```bash
   # Run these commands (replace YOUR_USERNAME):
   git remote add origin https://github.com/YOUR_USERNAME/bungus-valley.git
   git branch -M main
   git push -u origin main
   ```

3. **Enable GitHub Pages:**
   - Go to your repository on GitHub
   - Click "Settings" → "Pages"
   - Source: Select "gh-pages" branch
   - Click "Save"

4. **Wait 2-5 minutes** for deployment

5. **Visit your site:**
   ```
   https://YOUR_USERNAME.github.io/bungus-valley/
   ```

---

## 🎯 Even Easier: Use the Automated Script

### **Mac/Linux:**
```bash
chmod +x deploy-to-github.sh
./deploy-to-github.sh
```

### **Windows:**
Just double-click: `deploy-to-github.bat`

The script will guide you through everything!

---

## ✅ What You'll Get

- ✅ Free hosting on GitHub Pages
- ✅ Live website in minutes
- ✅ Automatic HTTPS/SSL
- ✅ Global CDN (fast worldwide)
- ✅ Easy updates

---

## 🔄 How to Update Later

Whenever you make changes:

```bash
git add .
git commit -m "Updated website"
git push
npm run deploy
```

That's it! Your site updates in 2-5 minutes.

---

## 🆘 Need Help?

### If you get errors:

**"gh-pages not found":**
```bash
npm install gh-pages --save-dev
```

**"Build failed":**
```bash
npm install
npm run build
```

**"Permission denied":**
- Make sure you're logged into GitHub
- Use: `git config --global user.email "your@email.com"`
- Use: `git config --global user.name "Your Name"`

---

## 🎉 That's It!

Your Bungus Valley website is now live and ready to share with the world!

**Live URL:** `https://YOUR_USERNAME.github.io/bungus-valley/`

**Next:** Set up custom domain (bungusvalley.com) if you have one. See `GITHUB_PAGES_DEPLOYMENT.md` for details.

---

**Questions?** Check the detailed guide: `GITHUB_PAGES_DEPLOYMENT.md`